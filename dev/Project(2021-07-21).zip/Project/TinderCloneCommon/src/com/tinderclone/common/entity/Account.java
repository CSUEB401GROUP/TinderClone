package com.tinderclone.common.entity;

public class Account {

}
