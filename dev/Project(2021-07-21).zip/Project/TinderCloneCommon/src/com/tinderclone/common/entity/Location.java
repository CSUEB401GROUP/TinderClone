package com.tinderclone.common.entity;

public class Location {

	private String city;
	private int distance;
	
	public Integer getDistance(String city1, String city2) {
		return 0;
	}
}
