package com.tinderclone.common.entity;

public class Filter {

	private int age;
	private String gender;
	private int distance;
	
	public void editFilterSetting(String field, String value) {
		
	}
	
	public ProfileList filterProfiles(ProfileList profileList) {
		return null;
	}
	
	public String getName() {
		return null;
	}
	
	public String getValue() {
		return null;
	}
	
	public boolean compare(Attribute attribute) {
		return true;
	}
}
