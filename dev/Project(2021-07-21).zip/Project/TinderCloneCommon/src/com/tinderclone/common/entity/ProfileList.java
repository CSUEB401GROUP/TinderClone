package com.tinderclone.common.entity;

import java.util.List;

public class ProfileList {

	public ProfileList(List<Profile> profiles) {
		super();
	}

	private String user_id;
	private String profile;
	private String index;
	
	public boolean addProfile() {
		return false;
	}
	
	public Profile getNextProfile() {
		return null;
	}
	
	public Profile getProfile(int index) {
		return null;
	}
	
	public Profile getProfile(String user_id) {
		return null;
	}
	
	
	
}
