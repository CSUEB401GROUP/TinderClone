package com.tinderclone.common.entity;

public class Picture {

	private String path;

	public String getPath() { return path; }
	public void setPath(String path) { this.path = path; }
}
