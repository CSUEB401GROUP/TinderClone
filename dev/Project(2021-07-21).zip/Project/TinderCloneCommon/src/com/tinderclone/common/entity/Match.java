package com.tinderclone.common.entity;

import java.util.Date;

public class Match {

	public Profile getProfile() {
		return null;
	}
	
	public Date getMatchDate() {
		return null;
	}
	
	public String getUserID() {
		return null;
	}
}
