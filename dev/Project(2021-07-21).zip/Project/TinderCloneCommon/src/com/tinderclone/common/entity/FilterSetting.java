package com.tinderclone.common.entity;

public class FilterSetting {

	public String getName() {
		return null;
	}
	
	public String getValue() {
		return null;
	}
	
	public boolean compare(Attribute attribute) {
		return true;
	}
}
