package com.tinderclone.server;
import com.tinderclone.server.core.DataHost;

public class Driver{
	
	public static void main(String[] args) {
		DataHost dh = new DataHost();
	}
	
}